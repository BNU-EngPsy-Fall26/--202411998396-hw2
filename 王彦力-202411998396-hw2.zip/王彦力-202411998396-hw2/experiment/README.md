# 注意实验室实验程序

本目录保留 P06–P10 使用的 attention-lab-final-1.0 程序及 change_blind_v1.0 素材。

从本目录运行 `python3 serve.py`，通过终端显示的本机地址访问邀请页。也可以运行 `python3 -m http.server 8000 --bind 127.0.0.1`，打开 `http://127.0.0.1:8000/invite.html`。

`invite.html` 进入 `index.html?pilot=1`，完成后下载匿名JSON。`?test=1` 是缩短变化盲与动画时长的开发入口，不用于研究数据。本次程序及数据的实际局限、结果、预测与AI说明见根目录README及主报告。
