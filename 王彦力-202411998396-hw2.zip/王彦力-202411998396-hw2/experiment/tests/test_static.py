from pathlib import Path
import json, re, struct
ROOT=Path(__file__).resolve().parents[1]
mat=ROOT/'materials/change_blind_v1.0'
assert (ROOT/'index.html').exists()
assert (ROOT/'src/app.js').exists()
assert len(list((mat/'images').glob('*.png')))==48
assert len(list((mat/'practice').glob('*.png')))==4
for p in list((mat/'images').glob('*.png'))+list((mat/'practice').glob('*.png')):
    data=p.read_bytes()
    assert data[:8]==b'\x89PNG\r\n\x1a\n',p
    w,h=struct.unpack('>II',data[16:24])
    assert (w,h)==(1280,720),(p,w,h)
rows=json.loads((mat/'manifest.json').read_text())
assert len(rows)==26
formal=[r for r in rows if r['id'].startswith('CB')]
assert sum(r['listA_condition']=='valid' for r in formal)==12
assert sum(r['listA_condition']=='neutral' for r in formal)==12
for r in formal:
    assert r['listA_condition'] != r['listB_condition']
js=(ROOT/'src/app.js').read_text()
for token in ['performance.now','stroop','flicker','inattentional','event_once','const mode','for(let i=0;i<10;i++)']:
    assert token in js, token
print('static checks passed: 52 stimulus PNGs, 26 manifest rows, conditions balanced, core modules present')
