"""Serve only the experiment folder on a free loopback port. Python 3 stdlib."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

def main():
    directory = str(Path(__file__).resolve().parent)
    handler = partial(SimpleHTTPRequestHandler, directory=directory)
    with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
        url = f'http://127.0.0.1:{server.server_port}/invite.html'
        print(f'Open {url} in your browser. Press Ctrl+C to stop.', flush=True)
        try:
            webbrowser.open(url)
        except webbrowser.Error:
            pass
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass

if __name__ == '__main__':
    main()
