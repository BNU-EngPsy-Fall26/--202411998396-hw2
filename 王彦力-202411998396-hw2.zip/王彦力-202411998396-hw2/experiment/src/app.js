const app = document.querySelector('#app');
const params = new URLSearchParams(location.search);
const TEST_MODE = params.get('test') === '1';
const PILOT_MODE = params.get('pilot') === '1';
const SOFTWARE_VERSION = 'attention-lab-final-1.0';
const STIMULUS_VERSION = 'change_blind_v1.0';
const COLORS = [
  {name:'红', hex:'#d54b45', key:'d'},
  {name:'绿', hex:'#4e9b68', key:'f'},
  {name:'蓝', hex:'#4d76bd', key:'j'},
  {name:'黄', hex:'#d3a934', key:'k'}
];
const mode = TEST_MODE ? 'test' : PILOT_MODE ? 'pilot' : 'local';
const now = () => performance.now();
function participantParity(pid){const m=String(pid).match(/(\d+)$/);if(m)return Number(m[1])%2;return [...String(pid)].reduce((a,c)=>a+c.charCodeAt(0),0)%2;}
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {
  screen:'consent', participant:'', order:['stroop','flicker','inattentional'], orderIndex:0,
  condition:'', flickerList:'A', flickerSeed:null, flickerOrder:null,
  results:[], test:TEST_MODE, mode
};
function shell(title, sub='') {
  const badge = mode === 'test' ? '开发测试' : mode === 'pilot' ? '最终试测版' : '本地模式';
  return `<div class="panel"><div class="topline"><div><div class="brand">ATTENTION LAB</div><h1>${title}</h1>${sub?`<p class="muted">${sub}</p>`:''}</div><span class="pill">${badge}</span></div>`;
}
function endShell(){return `</div><div class="footer">注意实验室 · ${SOFTWARE_VERSION} · 数据不会自动上传</div>`;}
function render(){
  if(state.screen==='consent') return renderConsent();
  if(state.screen==='participant') return renderParticipant();
  if(state.screen==='intro') return renderIntro();
  if(state.screen==='stroop') return renderStroop();
  if(state.screen==='flicker') return renderFlicker();
  if(state.screen==='inattentional') return renderInattentional();
  if(state.screen==='finish') return renderFinish();
  if(state.screen==='results') return renderResults();
}
function renderConsent(){
  app.innerHTML = shell('注意实验室','选择性注意、变化盲与非注意盲') + `<div class="notice"><strong>参与说明</strong><p>这是工程心理学课程实验。页面记录匿名编号、按键、反应时和实验条件，不收集姓名、学号、邮箱、摄像或录音。你可以随时退出。</p></div><div class="checkbox"><input id="agree" type="checkbox"><label for="agree">我已阅读说明，自愿参与本次实验，并同意记录匿名实验反应。</label></div><div class="button-row"><button class="btn" id="start" disabled>继续</button></div>` + endShell();
  document.querySelector('#agree').onchange = e => { document.querySelector('#start').disabled = !e.target.checked; };
  document.querySelector('#start').onclick = () => { state.screen='participant'; render(); };
}
function renderParticipant(){
  app.innerHTML = shell('开始实验','请输入匿名编号，勿填写身份信息') + `<div class="form-grid"><div class="field"><label for="pid">匿名参与者编号</label><input id="pid" maxlength="20" placeholder="例如 P06"><span class="muted small">请勿输入姓名、学号、手机号或邮箱。</span></div><div class="field"><label for="order">实验顺序</label><select id="order"><option value="fixed">Stroop → 变化盲 → 非注意盲</option><option value="reverse">非注意盲 → 变化盲 → Stroop</option></select></div></div><div class="button-row"><button class="btn" id="go">进入指导语</button></div>` + endShell();
  document.querySelector('#go').onclick = () => { const p=document.querySelector('#pid').value.trim(); if(!p){alert('请输入匿名编号');return;} state.participant=p; const parity=participantParity(p); state.condition=parity===0?'high_load':'low_load'; state.flickerList=parity===0?'B':'A'; state.order=document.querySelector('#order').value==='reverse'?['inattentional','flicker','stroop']:['stroop','flicker','inattentional']; state.screen='intro'; render(); };
}
function renderIntro(){
  const exp=state.order[state.orderIndex]; const names={stroop:'Stroop 颜色词任务',flicker:'闪烁范式变化盲',inattentional:'非注意盲持续注意任务'}; const desc={stroop:'忽略词义，尽快判断字体颜色。',flicker:'观察 A 与 A′ 场景交替，发现变化后报告并定位。',inattentional:'完成传球计数任务，随后回答是否注意到意外事件。'};
  app.innerHTML=shell(`实验 ${state.orderIndex+1}/3：${names[exp]}`,desc[exp])+`<div class="notice"><strong>先进行练习</strong><p>练习用于熟悉操作，不进入正式分析。正式实验中请尽量保持注意和反应方式一致。</p></div><div class="cards"><div class="card"><strong>当前实验</strong><p>${names[exp]}</p></div><div class="card"><strong>匿名编号</strong><p>${esc(state.participant)}</p></div></div><div class="button-row"><button class="btn" id="begin">开始</button></div>`+endShell();
  document.querySelector('#begin').onclick=()=>{state.screen=exp;render();};
}
function record(experiment,row){state.results.push({software_version:SOFTWARE_VERSION,stimulus_version:STIMULUS_VERSION,participant:state.participant,experiment,test:state.test,mode,timestamp:new Date().toISOString(),...row});}
// Stroop: 4 practice + 10 formal per condition.
const stroopTrials=[];
for(let i=0;i<4;i++){const c=COLORS[i];stroopTrials.push({condition:'practice',word:c.name,color:c,correct:c.key,practice:true,index:stroopTrials.length});}
for(const condition of ['congruent','incongruent','neutral']) for(let i=0;i<10;i++){
  const target=i%4; const color=COLORS[target]; const word=condition==='neutral'?'XXXX':condition==='congruent'?color.name:COLORS[(target+1)%4].name;
  stroopTrials.push({condition,word,color,correct:color.key,practice:false,index:stroopTrials.length});
}
let stroopIndex=0, stroopStart=0;
function renderStroop(){
  if(stroopIndex>=stroopTrials.length){stroopIndex=0;state.orderIndex++;state.screen=state.orderIndex<state.order.length?'intro':'finish';render();return;}
  const t=stroopTrials[stroopIndex]; const label=t.practice?`练习 ${stroopIndex+1}/4`:`正式 ${stroopIndex-3}/30`;
  app.innerHTML=shell('Stroop 颜色词任务',label)+`<div class="progress"><div style="width:${(stroopIndex/stroopTrials.length)*100}%"></div></div><div class="stimulus" style="min-height:260px;margin-top:22px"><div style="font-size:76px;font-weight:800;color:${t.color.hex};letter-spacing:.12em">${t.word}</div></div><p class="center muted">请按字体颜色对应的键：红 D、绿 F、蓝 J、黄 K</p><div class="key-grid">${COLORS.map(c=>`<button class="key" data-key="${c.key}">${c.name}<br><span class="small">${c.key.toUpperCase()}</span></button>`).join('')}</div>`+endShell();
  stroopStart=now(); const answer=key=>{if(!stroopStart)return;const rt=now()-stroopStart;record('stroop',{trial_index:t.index,condition:t.condition,word:t.word,color:t.color.name,response:key,correct:key===t.correct,rt_ms:Math.round(rt),practice:t.practice});stroopStart=0;stroopIndex++;document.onkeydown=null;setTimeout(render,TEST_MODE?5:40);};
  document.querySelectorAll('.key').forEach(b=>b.onclick=()=>answer(b.dataset.key)); document.onkeydown=e=>{if(COLORS.some(c=>c.key===e.key))answer(e.key);};
}
// Flicker: constrained random order plus real cue phase.
let flickerManifest=[],flickerIndex=0,flickerTimer=null,flickerTimeout=null,flickerPhase=0,flickerStarted=0,flickerFound=false;
function seededRandom(seed){return()=>{seed=(seed+0x6D2B79F5)|0;let t=Math.imul(seed^(seed>>>15),1|seed);t^=t+Math.imul(t^(t>>>7),61|t);return((t^(t>>>14))>>>0)/4294967296;};}
function shuffle(items,rng){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function balancedOrder(order){
  const halves=[order.slice(0,12),order.slice(12)]; const qk=['TL','TR','BL','BR']; const tk=['颜色变化','位置变化','物体出现','物体消失'];
  for(const part of halves){const q=Object.fromEntries(qk.map(x=>[x,0])),t=Object.fromEntries(tk.map(x=>[x,0])),c={valid:0,neutral:0};for(const x of part){q[x.quadrant]++;t[x.change_type]++;c[state.flickerList==='A'?x.listA_condition:x.listB_condition]++;}if(Object.values(q).some(x=>x!==3)||Object.values(t).some((x,i)=>x!==[4,4,2,2][i])||c.valid!==6||c.neutral!==6)return false;}
  for(let i=2;i<order.length;i++){if(order[i].quadrant===order[i-1].quadrant&&order[i].quadrant===order[i-2].quadrant)return false;if(order[i].change_type===order[i-1].change_type&&order[i].change_type===order[i-2].change_type)return false;}return true;
}
function prepareFlickerOrder(){if(state.flickerOrder)return;state.flickerSeed=crypto.getRandomValues(new Uint32Array(1))[0];const rng=seededRandom(state.flickerSeed);for(let i=0;i<5000;i++){const candidate=shuffle(flickerManifest,rng);if(balancedOrder(candidate)){state.flickerOrder=candidate;flickerManifest=candidate;state.flickerOrderIds=candidate.map(x=>x.id);return;}}state.flickerOrder=shuffle(flickerManifest,rng);flickerManifest=state.flickerOrder;state.flickerOrderIds=flickerManifest.map(x=>x.id);}
async function renderFlicker(){
  if(!flickerManifest.length){try{flickerManifest=(await fetch(`materials/${STIMULUS_VERSION}/manifest.json`).then(r=>r.json())).filter(x=>x.id.startsWith('CB'));prepareFlickerOrder();}catch(e){app.innerHTML=shell('变化盲加载失败')+`<div class="notice error">无法加载本地素材，请返回并重新打开页面。</div>`+endShell();return;}}
  const limit=TEST_MODE?2:24;if(flickerIndex>=limit){flickerIndex=0;state.orderIndex++;state.screen=state.orderIndex<state.order.length?'intro':'finish';render();return;}
  const t=flickerManifest[flickerIndex];const cueType=(state.flickerList==='A'?t.listA_condition:t.listB_condition);const cueText=cueType==='valid'?'请先观察提示位置，再观察场景变化。':'请观察场景变化。';
  app.innerHTML=shell('闪烁范式变化盲',`正式试次 ${flickerIndex+1}/${limit}`)+`<div class="notice"><strong>操作</strong><p>${cueText}发现变化后点击“发现变化”，再选择大致象限。提示框不会告诉你实验条件。</p></div><div class="stimulus cue-stage"><img id="flicker-img" alt="场景"><div id="cue-overlay" class="cue-overlay"></div></div><div class="button-row"><button class="btn" id="found">发现变化</button><button class="btn secondary" id="skip">跳过</button></div><div id="locate" hidden class="notice"><p>请选择变化所在象限：</p><div class="button-row"><button class="btn secondary" data-q="TL">左上</button><button class="btn secondary" data-q="TR">右上</button><button class="btn secondary" data-q="BL">左下</button><button class="btn secondary" data-q="BR">右下</button></div></div>`+endShell();
  flickerFound=false;flickerPhase=0;flickerStarted=0;clearTimeout(flickerTimer);clearTimeout(flickerTimeout);const img=document.querySelector('#flicker-img');const overlay=document.querySelector('#cue-overlay');
  // Equal-duration cue: valid marks the target quadrant; neutral uses the center.
  if(cueType==='valid'){overlay.className='cue-overlay cue-valid '+t.quadrant;overlay.textContent='';}else{overlay.className='cue-overlay cue-neutral';overlay.textContent='';}
  img.src=`materials/${STIMULUS_VERSION}/${t.file_A}`;
  const cueDuration=TEST_MODE?350:500;
  flickerTimer=setTimeout(()=>{overlay.className='cue-overlay hidden';startFlicker();},cueDuration);
  document.querySelector('#found').onclick=()=>flickerAnswer('found');document.querySelector('#skip').onclick=()=>flickerAnswer('skip');
  function startFlicker(){flickerStarted=now();flickerPhase=0;showFrame();if(!TEST_MODE)flickerTimeout=setTimeout(()=>flickerAnswer('timeout'),60000);}
  function showFrame(){if(flickerFound)return;flickerPhase=(flickerPhase+1)%4;if(flickerPhase===0)img.src=`materials/${STIMULUS_VERSION}/${t.file_A}`;else if(flickerPhase===2)img.src=`materials/${STIMULUS_VERSION}/${t.file_Ap}`;else img.removeAttribute('src');flickerTimer=setTimeout(showFrame,TEST_MODE?180:320);}
  function flickerAnswer(response){if(flickerFound||!flickerStarted)return;flickerFound=true;clearTimeout(flickerTimer);clearTimeout(flickerTimeout);const rt=Math.round(now()-flickerStarted);const common={trial_index:flickerIndex,sequence_index:flickerIndex,sequence_id:t.id,random_seed:state.flickerSeed,list:state.flickerList,condition:cueType,change_type:t.change_type,quadrant:t.quadrant,cue_type:cueType,cue_duration_ms:cueDuration,practice:false};if(response==='found'){document.querySelector('#locate').hidden=false;document.querySelector('#found').disabled=true;document.querySelector('#skip').disabled=true;document.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>{record('flicker',{...common,response:'found',rt_ms:rt,quadrant_response:b.dataset.q,quadrant_correct:b.dataset.q===t.quadrant});next();});}else{record('flicker',{...common,response,rt_ms:rt,quadrant_response:'',quadrant_correct:false});next();}}
  function next(){flickerIndex++;flickerStarted=0;setTimeout(render,TEST_MODE?5:100);}
}
// Inattentional blindness: one unexpected event per participant.
let inattentionalDone=false,ballStart=0,ballTimer=null,ballCount=0,eventShown=false;
function renderInattentional(){
  if(inattentionalDone){state.orderIndex++;state.screen=state.orderIndex<state.order.length?'intro':'finish';render();return;}
  if(!ballStart){ballStart=now();ballCount=0;eventShown=false;setTimeout(()=>{eventShown=true;},TEST_MODE?650:3500);ballTimer=setInterval(()=>{ballCount++;drawBalls();if(now()-ballStart>(TEST_MODE?2200:10000)){clearInterval(ballTimer);ballTimer=null;renderInattentionalPost();}},TEST_MODE?180:450);}
  app.innerHTML=shell('非注意盲持续注意任务','完成传球计数后回答事后问题')+`<div class="notice"><strong>当前任务：${state.condition==='low_load'?'低负荷':'高负荷'}</strong><p>${state.condition==='low_load'?'统计所有传球。':'只统计空中传球，忽略反弹传球。'} 动画中可能出现一个意外刺激，请先完成计数。</p></div><div class="canvas-wrap"><canvas id="ball-canvas" width="760" height="430"></canvas></div><div class="center"><p>当前计数：<span id="count" class="big-number">0</span></p><p class="muted">动画结束后会自动进入事后询问。</p></div>`+endShell();drawBalls();
}
function drawBalls(){const c=document.querySelector('#ball-canvas');if(!c)return;const ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#7898a4';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#dce9df';ctx.fillRect(0,c.height*.72,c.width,c.height*.28);for(let i=0;i<4;i++){ctx.fillStyle=i%2?'#d85c4d':'#4e7fa6';ctx.beginPath();ctx.arc(c.width*(.25+i*.17),c.height*.48+Math.sin(ballCount*.4+i)*18,24,0,Math.PI*2);ctx.fill();}ctx.fillStyle='#f2c84b';ctx.beginPath();ctx.arc(c.width*(.15+.7*((Math.sin(ballCount*.42)+1)/2)),c.height*(.35+.25*Math.sin(ballCount*.7)),17,0,Math.PI*2);ctx.fill();if(eventShown){ctx.fillStyle='#7f4fa4';ctx.beginPath();ctx.arc(c.width*(.82-.035*ballCount),c.height*.22,30,0,Math.PI*2);ctx.fill();}const n=document.querySelector('#count');if(n)n.textContent=ballCount;}
function renderInattentionalPost(){app.innerHTML=shell('非注意盲｜事后询问','请先自由回忆，再回答识别题')+`<div class="form-grid"><div class="field"><label for="free">1. 刚才视频中，你注意到哪些内容或事件？</label><textarea id="free" rows="4"></textarea></div><div class="field"><label for="aware">2. 你是否注意到一个与传球无关的意外刺激？</label><select id="aware"><option value="yes">是</option><option value="no">否</option><option value="unsure">不确定</option></select></div><div class="field"><label for="passes">3. 你统计的传球数量</label><input id="passes" type="number" min="0" value="${ballCount}"></div></div><div class="button-row"><button class="btn" id="submit-inatt">提交答案</button></div>`+endShell();document.querySelector('#submit-inatt').onclick=()=>{record('inattentional',{condition:state.condition,pass_count:Number(document.querySelector('#passes').value),free_recall:document.querySelector('#free').value,unexpected_awareness:document.querySelector('#aware').value,event_once:true,rt_ms:Math.round(now()-ballStart)});inattentionalDone=true;ballStart=0;render();};}
function renderFinish(){app.innerHTML=shell('实验完成','感谢参与本次实验')+`<div class="notice success"><strong>数据已暂存</strong><p>${mode==='pilot'?'请点击“下载匿名数据”，把 JSON 文件按研究者指定方式交回。页面不会自动上传。':'当前为本地测试模式。'}</p></div><div class="button-row"><button class="btn" id="view">查看摘要</button><button class="btn secondary" id="download">下载匿名数据</button></div>`+endShell();document.querySelector('#view').onclick=()=>{state.screen='results';render();};document.querySelector('#download').onclick=downloadData;}
function renderResults(){const groups={};for(const r of state.results)(groups[r.experiment]??=[]).push(r);app.innerHTML=shell('测试摘要','当前浏览器内存中的本次数据')+`<div class="cards">${Object.entries(groups).map(([k,v])=>`<div class="card"><strong>${k}</strong><p>${v.length} 条记录</p></div>`).join('')}</div><div class="notice"><strong>重要</strong><p>本页只展示本次运行的匿名数据。正式研究分析前仍需执行版本、缺失、异常 RT 和知情同意检查。</p></div><div class="button-row"><button class="btn" id="download2">下载 JSON</button><button class="btn secondary" id="again">重新开始</button></div>`+endShell();document.querySelector('#download2').onclick=downloadData;document.querySelector('#again').onclick=()=>location.reload();}
function downloadData(){const payload={version:mode==='pilot'?'pilot-final-1.0':'test-final-1.0',software_version:SOFTWARE_VERSION,stimulus_version:STIMULUS_VERSION,test:state.test,mode,participant:state.participant,flicker_list:state.flickerList,flicker_seed:state.flickerSeed,flicker_sequence:state.flickerOrderIds||[],trials:state.results};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`attention-lab-${mode}-${state.participant||'anonymous'}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}
render();
