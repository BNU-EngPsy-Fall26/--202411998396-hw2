# 数据字典与计算规则

## 通用原始字段

| 字段 | 含义 |
| --- | --- |
| participant | 匿名编号，本分析 P06–P10 |
| experiment | stroop、flicker、inattentional |
| software_version / stimulus_version | 实际软件与素材版本 |
| version | 文件格式版本 pilot-final-1.0 |
| mode / test | 本次均为 pilot / false；test false 不能单独证明真实身份或同意记录 |
| timestamp | UTC 反应记录时间；不是独立屏幕呈现时刻 |
| rt_ms | 毫秒；三项任务起止定义不同，不能直接相互比较 |
| practice | 练习标记；Stroop 四次为 true |

## Stroop

`condition` 为 practice、congruent、incongruent、neutral。`word` 为屏幕文字，`color` 为目标字体颜色，`response` 为颜色键。`correct` 根据红 d、绿 f、蓝 j、黄 k 计算。`trial_index` 从 0 开始，正式为 4–33。准确率为正确数/10；RT 汇总仅使用正确反应，不含练习。错误反应保留在源文件和长表中。

## 变化盲

| 字段 | 含义 |
| --- | --- |
| flicker_seed / random_seed | 文件级和试次级随机种子 |
| flicker_sequence / sequence_id | 文件级顺序和本试次材料 ID |
| sequence_index / trial_index | 从 0 开始的实际呈现序号 |
| list / flicker_list | A 或 B，交换同一材料的线索条件 |
| condition / cue_type | valid 或 neutral |
| change_type | 颜色变化、位置变化、物体出现、物体消失 |
| quadrant | 真实目标象限 TL、TR、BL、BR |
| cue_duration_ms | 本次名义线索时长 500 ms |
| response | found、skip 或 timeout；本次均为 found |
| quadrant_response / quadrant_correct | 报告象限及是否正确 |
| rt_ms | 线索结束后开始计时，止于发现按钮点击，含空屏阶段 |

`found_rate` = found 数/12；`confirmed_rate` = found 且 quadrant_correct 的数量/12。`median_ms`、`mean_ms` 均只使用核验通过试次；`found_median_ms` 则只要求自报发现，用于核对。

## 意外刺激

`condition` 为 low_load 或 high_load，是指导语标签，不等于已验证负荷差异。`pass_count` 为提交的计数，程序显示并预填计数，没有已验证主任务标准答案。`free_recall` 保留开放回答原文；`unexpected_awareness` 为 yes、no、unsure。`event_once` 是程序写入的常量，不是逐帧播放审计证明。此任务 `rt_ms` 包含动画与填写时间，不是刺激发现 RT。

派生 `purple_mentioned` 仅检查开放原文是否含“紫色”，不改写识别回答。Wilson 区间针对回答 yes 的比例描述；unsure 保留为第三类，不合并为 no。

## 汇总统计

每名参与者先计算条件 RT 中位数，再求五人的均值及样本标准差；`mean_mean_ms` 为五个个体正确试次均值的均值，而非不加区分地合并所有试次。干扰量 = Stroop 不一致 − 一致。线索收益 = 变化盲中性 − 有效。核验率收益 = 有效核验率 − 中性核验率，以百分点表示。

`dz` = 个体差值均值/个体差值标准差。`ci95_t` 为差值均值 ± 2.776445105 × SD/√5。`p_exact_two_sided` 穷举 32 个符号向量，统计差值和的绝对值不少于实际值的比例。区间和 p 使用不同假设，不应混用为同一种显著性判据。

缺失值不填补，低准确率不作为事后排除参与者的理由。敏感性阈值只作用于变化盲 RT 汇总，不覆盖源数据、不影响主分析分母。每项 RT 的有效试次数均可从参与者条件表复核。
