// Reconstruct the implemented shuffle, including its unconstrained fallback.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'analysis/material_manifest.json'))).filter(x=>x.id.startsWith('CB'));
function seededRandom(seed){return()=>{seed=(seed+0x6D2B79F5)|0;let t=Math.imul(seed^(seed>>>15),1|seed);t^=t+Math.imul(t^(t>>>7),61|t);return((t^(t>>>14))>>>0)/4294967296;};}
function shuffle(items,rng){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function balanced(order,list){
 for(const a of [order.slice(0,12),order.slice(12)]){
  for(const [k,expected] of Object.entries({quadrant:{TL:3,TR:3,BL:3,BR:3},change_type:{'颜色变化':4,'位置变化':4,'物体出现':2,'物体消失':2},['list'+list+'_condition']:{valid:6,neutral:6}}))
   for(const [v,n] of Object.entries(expected))if(a.filter(x=>x[k]===v).length!==n)return false;
 }
 for(let i=2;i<order.length;i++)for(const k of ['quadrant','change_type'])if(order[i][k]===order[i-1][k]&&order[i][k]===order[i-2][k])return false;
 return true;
}
let results=[];
for(let n=6;n<=10;n++){
 const d=JSON.parse(fs.readFileSync(path.join(root,`data/raw/attention-lab-pilot-P${String(n).padStart(2,'0')}.json`)));
 const rng=seededRandom(d.flicker_seed);let order=null,attempts=0;
 for(let i=0;i<5000;i++){let a=shuffle(manifest,rng);attempts++;if(balanced(a,d.flicker_list)){order=a;break;}}
 const fallback=order===null;if(fallback)order=shuffle(manifest,rng);
 const reproduced=JSON.stringify(order.map(x=>x.id))===JSON.stringify(d.flicker_sequence);
 if(!reproduced)throw Error('Sequence mismatch '+d.participant);
 results.push({participant:d.participant,seed:d.flicker_seed,list:d.flicker_list,attempts,fallback,reproduced});
}
fs.writeFileSync(path.join(root,'results/randomization_audit.json'),JSON.stringify(results,null,2));
console.log(results);
