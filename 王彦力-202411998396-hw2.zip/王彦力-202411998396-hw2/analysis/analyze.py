"""Reproduce P06–P10 analyses. Python standard library only; run from any cwd.
Retrospective exploratory rules: exclude practice and incorrect trials from Stroop RT;
confirmed Flicker = found AND correct quadrant. No RT trimming or participant exclusion.
Participant is the independent unit. p is two-sided exact sign-flip, exploratory only.
"""
from pathlib import Path
import json, csv, hashlib, statistics as st, math, itertools
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
PIDS = ['P06','P07','P08','P09','P10']
manifest = {x['id']:x for x in json.loads((ROOT/'analysis/material_manifest.json').read_text()) if x['id'].startswith('CB')}
rows, subjects, audit, hashes = [], [], [], {}
def avg(x): return st.mean(x) if x else None
def med(x): return st.median(x) if x else None
def sd(x): return st.stdev(x) if len(x)>1 else None
def paired(d):
    mean=avg(d); s=sd(d); se=s/math.sqrt(len(d)); crit=2.7764451051977987
    p=sum(abs(sum(x*y for x,y in zip(sign,d))) >= abs(sum(d))-1e-8 for sign in itertools.product([-1,1],repeat=len(d)))/(2**len(d))
    return dict(n=len(d),differences=d,mean=mean,sd=s,dz=mean/s if s else None,ci95_t=[mean-crit*se,mean+crit*se],p_exact_two_sided=p)
for pid in PIDS:
    p=ROOT/'data/raw'/f'attention-lab-pilot-{pid}.json'; b=p.read_bytes(); hashes[p.name]=hashlib.sha256(b).hexdigest()
    d=json.loads(b); r=d['trials']; assert len(r)==59 and d['participant']==pid and not d['test']
    assert d['software_version']=='attention-lab-final-1.0' and d['stimulus_version']=='change_blind_v1.0'
    assert all(x['participant']==pid and x['mode']=='pilot' and not x['test'] and x['rt_ms']>0 for x in r)
    assert len({(x['experiment'],x.get('trial_index',0)) for x in r})==59
    s=[x for x in r if x['experiment']=='stroop']; f=[x for x in r if x['experiment']=='flicker']; ib=[x for x in r if x['experiment']=='inattentional']
    assert len(s)==34 and len(f)==24 and len(ib)==1
    assert len([x for x in s if x['practice']])==4
    q={'participant':pid,'list':d['flicker_list'],'load':ib[0]['condition'],'seed':d['flicker_seed'],'order':list(dict.fromkeys(x['experiment'] for x in r)), 'first_timestamp':r[0]['timestamp'],'last_timestamp':r[-1]['timestamp']}
    for c in ['congruent','incongruent','neutral']:
        a=[x for x in s if x['condition']==c]; assert len(a)==10
        for x in a: assert x['correct']==(x['response']==dict(zip('红绿蓝黄','dfjk'))[x['color']])
        good=[x['rt_ms'] for x in a if x['correct']]
        q['stroop_'+c]={'n':len(a),'correct':len(good),'accuracy':len(good)/len(a),'median_ms':med(good),'mean_ms':avg(good),'min_ms':min(good),'max_ms':max(good)}
    assert [x['sequence_id'] for x in f]==d['flicker_sequence']
    assert len(set(d['flicker_sequence']))==24 and set(d['flicker_sequence'])==set(manifest)
    for idx,x in enumerate(f):
        m=manifest[x['sequence_id']]
        assert x['condition']==m['list'+d['flicker_list']+'_condition'] and x['quadrant']==m['quadrant'] and x['change_type']==m['change_type']
        assert x['quadrant_correct']==(x['quadrant_response']==x['quadrant'])
        assert x['trial_index']==idx and x['sequence_index']==idx and x['random_seed']==d['flicker_seed'] and x['cue_duration_ms']==500
    halves=[]
    for a in [f[:12],f[12:]]:
        counts={k:dict(Counter(x[k] for x in a)) for k in ['quadrant','condition','change_type']}
        balanced=(all(counts['quadrant'].get(k,0)==3 for k in ['TL','TR','BL','BR']) and all(counts['condition'].get(k,0)==6 for k in ['valid','neutral']) and all(counts['change_type'].get(k,0)==v for k,v in {'颜色变化':4,'位置变化':4,'物体出现':2,'物体消失':2}.items()))
        halves.append({'counts':counts,'balanced':balanced})
    runs={k:any(f[i][k]==f[i-1][k]==f[i-2][k] for i in range(2,24)) for k in ['quadrant','change_type']}
    for c in ['valid','neutral']:
        a=[x for x in f if x['condition']==c]; assert len(a)==12
        found=[x for x in a if x['response']=='found']; good=[x for x in found if x['quadrant_correct']]
        q['flicker_'+c]={'n':len(a),'found':len(found),'confirmed':len(good),'found_rate':len(found)/len(a),'confirmed_rate':len(good)/len(a),'median_ms':med([x['rt_ms'] for x in good]),'mean_ms':avg([x['rt_ms'] for x in good]),'found_median_ms':med([x['rt_ms'] for x in found]),'skip':sum(x['response']=='skip' for x in a),'timeout':sum(x['response']=='timeout' for x in a)}
    q['ib']=ib[0]; q['ib']['purple_mentioned']='紫色' in ib[0]['free_recall']
    subjects.append(q); rows.extend(r); audit.append({'participant':pid,'halves':halves,'three_in_row':runs})

summary={'n':5,'records':len(rows),'practice':20,'formal_stroop':150,'flicker':120,'ib':5,'subject_statistics':{},'paired':{},'audit':audit,'hashes':hashes}
for prefix,conds in [('stroop',['congruent','incongruent','neutral']),('flicker',['valid','neutral'])]:
    for c in conds:
        k=prefix+'_'+c; a=[s[k] for s in subjects]
        summary['subject_statistics'][k]={'mean_median_ms':avg([x['median_ms'] for x in a]),'sd_median_ms':sd([x['median_ms'] for x in a]),'mean_mean_ms':avg([x['mean_ms'] for x in a])}
        for rate in (['accuracy'] if prefix=='stroop' else ['found_rate','confirmed_rate']):summary['subject_statistics'][k][rate]=avg([x[rate] for x in a])
summary['paired']['stroop_interference']=paired([s['stroop_incongruent']['median_ms']-s['stroop_congruent']['median_ms'] for s in subjects])
summary['paired']['stroop_incongruent_minus_neutral']=paired([s['stroop_incongruent']['median_ms']-s['stroop_neutral']['median_ms'] for s in subjects])
summary['paired']['stroop_neutral_minus_congruent']=paired([s['stroop_neutral']['median_ms']-s['stroop_congruent']['median_ms'] for s in subjects])
summary['paired']['flicker_benefit']=paired([s['flicker_neutral']['median_ms']-s['flicker_valid']['median_ms'] for s in subjects])
summary['paired']['flicker_meanRT_benefit']=paired([s['flicker_neutral']['mean_ms']-s['flicker_valid']['mean_ms'] for s in subjects])
summary['paired']['flicker_confirmation_benefit']=paired([100*(s['flicker_valid']['confirmed_rate']-s['flicker_neutral']['confirmed_rate']) for s in subjects])
summary['ranges']={e:{'min':min(x['rt_ms'] for x in rows if x['experiment']==e),'max':max(x['rt_ms'] for x in rows if x['experiment']==e)} for e in ['stroop','flicker','inattentional']}
summary['stroop_formal_under200']=sum(x['rt_ms']<200 for x in rows if x['experiment']=='stroop' and not x['practice'])
summary['flicker_sensitivity']={}
for cutoff in [320,640]:
    diffs=[]; detail=[]
    for pid in PIDS:
        vals={}
        for c in ['valid','neutral']:
            a=[x['rt_ms'] for x in rows if x['participant']==pid and x['experiment']=='flicker' and x['condition']==c and x['response']=='found' and x['quadrant_correct'] and x['rt_ms']>=cutoff]
            vals[c]=med(a)
        diffs.append(vals['neutral']-vals['valid']);detail.append({'participant':pid,**vals})
    summary['flicker_sensitivity'][str(cutoff)]={'excluded':sum(x['rt_ms']<cutoff for x in rows if x['experiment']=='flicker'), 'paired':paired(diffs),'detail':detail}
summary['ib_groups']={}
for c in ['low_load','high_load']:
    a=[s for s in subjects if s['load']==c];n=len(a);yes=sum(s['ib']['unexpected_awareness']=='yes' for s in a)
    z=1.95996398454;ph= yes/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
    summary['ib_groups'][c]={'n':n,'yes':yes,'unsure':sum(s['ib']['unexpected_awareness']=='unsure' for s in a),'no':sum(s['ib']['unexpected_awareness']=='no' for s in a),'purple_mentioned':sum(s['ib']['purple_mentioned'] for s in a),'wilson95':[center-half,center+half]}
summary['flicker_types']={}
for typ in ['颜色变化','位置变化','物体出现','物体消失']:
 a=[x for x in rows if x['experiment']=='flicker' and x['change_type']==typ]
 summary['flicker_types'][typ]={'n':len(a),'confirmed':sum(x['response']=='found' and x['quadrant_correct'] for x in a)}
(ROOT/'results/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(ROOT/'results/participants.json').write_text(json.dumps(subjects,ensure_ascii=False,indent=2))
def write_csv(name,records):
    fields=list(dict.fromkeys(k for r in records for k in r))
    with (ROOT/'results'/name).open('w',encoding='utf-8-sig',newline='') as out:
        w=csv.DictWriter(out,fieldnames=fields);w.writeheader();w.writerows(records)
write_csv('trial_data.csv',rows)
write_csv('participant_conditions.csv',[{'participant':s['participant'],'measure':k,**s[k]} for s in subjects for k in ['stroop_congruent','stroop_incongruent','stroop_neutral','flicker_valid','flicker_neutral']])
print(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(subjects,ensure_ascii=False,indent=2))
